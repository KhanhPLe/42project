/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/31 12:10:08 by kle               #+#    #+#             */
/*   Updated: 2022/02/03 09:22:19 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

int	str_len(char *str)
{
	int		i;

	i = 0;
	while (str[i] != 0)
	{
		write(1, &str[i], 1);
		i++;
	}
	return (i);
}

void	ft_strcpy( char *dest, char *src)
{
	int	i;
	int	j;

	i = 0;
	j = str_len(dest);
	while (dest[j] != 0 || src[i] != 0)
	{
		dest[j] = src[i];
		i++;
		j++;
	}
}

char	*ft_strdup(char *src)
{
	char	*dest;

	(void) src;
	{
		dest = malloc(str_len(src));
		ft_strcpy(dest, src);
	}
	return (dest);
}

/*int	main(void)
{
	char	*src;

	src = "abcde";
	ft_strdup(src);
	return (0);
}*/
