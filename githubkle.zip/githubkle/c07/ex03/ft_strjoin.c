/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/01 17:33:32 by kle               #+#    #+#             */
/*   Updated: 2022/02/03 14:50:51 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

int	str_len(char *str)
{
	int		len;

	len = 0;
	while (str[len] != 0)
	{
		write(1, &str[len], 1);
		len++;
	}
	return (len);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*dest;
	int	i;
	int	j;
	int	count;

	i = 0;
	j = 0;
	count = 0;
	while (strs[i])
	{
		count += str_len(strs[i]);
		count += str_len(sep);
   		i++;
	}	
	dest = malloc(count * sizeof(char));
	if (strs == NULL)
		return (0);
	while (j < size -1)
	{	
		i = 0;
		while (strs[j][i] != 0)
		{
			dest[i++] = strs[j][i++];
		}
		i = 0;
		while (sep[i] != 0)
		{
			dest[i] = sep[i];
			i++;
		}
		j++;
	}
	dest[i] = '\0';
	return (dest);
}
/*#include<stdio.h>
int main(void)
{
	char *strs[10];
	char	*sep;
	int	size;
	char *result;

	size = 2;
	strs[0]= "abcd";
	strs[1]= "efgh";
	sep = "...";
	result = ft_strjoin (size, strs, sep);
	printf("%s", result);
	return (0);
}*/
