/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/31 18:19:50 by kle               #+#    #+#             */
/*   Updated: 2022/02/03 09:24:23 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include<stdio.h>

int	ft_ultimate_range(int	**range, int min, int max)
{
	int	i;
	int	j;

	i = 0;
		*range = malloc((max - min) * sizeof(int));
	if (min >= max)
	{
		*range = NULL;
		return (0);
	}
	if (range == NULL)
		return (-1);
	while (min < max)
	{
		range[0][i] = min;
			min++;
			i++;
	}	
	return (i);
}
/*int	main(void)
{
	int	min;
	int	max;
	int	result;
	int	*range;
	int	i;

	i = 0;
	min = 5;
	max = 20;
	result = ft_ultimate_range(&range, min, max);
	printf("%d, ", result);
	return (0);
}*/
