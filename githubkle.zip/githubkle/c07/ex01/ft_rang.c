/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rang.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/31 15:11:23 by kle               #+#    #+#             */
/*   Updated: 2022/02/03 09:23:26 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>

int	*ft_list_num(int min, int max)
{
	int	*listnum;
	int	i;

	i = 0;
	listnum = malloc((max - min) * 4);
	while (min < max)
	{
		listnum[i] = min;
		min++;
		i++;
	}
	return (listnum);
}

int	*ft_range(int min, int max)
{
	int	*list_num;

	if (min >= max)
		return (0);
	else
	{
		list_num = ft_list_num(min, max);
		return (list_num);
	}
}
/*int	main(void)
{
	int	min;
	int	max;
	int	*result;
	int	i;

	min = 5;
	max = 150;
	i = 0;
	result = ft_range(min, max);
	while (i < max - min)
	{
		printf("%d, ", *result);
		i++;
		result ++;
	}	
	return (0);
}*/
