int main(int argc, char **argv)
{
	int	i;

	i = 0;
	if (argc !=2)
		write(1, "a\n", 1);
	return (0);
	while ( argv[0][i] != 'a')
	{
		i++;
	}
	write(1, "n", 1);
	return (0);
	while (
}
