/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dshukla <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/20 11:49:44 by dshukla           #+#    #+#             */
/*   Updated: 2022/01/21 09:09:41 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

int	ft_strlen(char *str)
{
	int		index;

	index = 0;
	while (str[index])
	{
		index++;
	}
	return (index);
}

#include <stdio.h>
int main(){
	char str[] = "";
	printf("string length is %d",ft_strlen(str));
	return 0;
}
