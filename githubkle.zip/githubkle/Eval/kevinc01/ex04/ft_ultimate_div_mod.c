/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kejoseph <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/27 15:01:29 by kejoseph          #+#    #+#             */
/*   Updated: 2022/02/03 14:39:17 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ultimate_div_mod(int *a, int *b)
{
	int	temp;

	temp = *a;
	*a = *a / *b;
	*b = temp % *b;
}

int main(void){
	int a, b, *ptra, *ptrb;
	a = 13;
	b = 5;
	ptra = &a;
	ptrb = &b;

	ft_ultimate_div_mod(ptra, ptrb);

	printf("The division of two numbers are %d\n", a);
	printf("The modulus of two numbers are %d", b);
	return 0;	
}

