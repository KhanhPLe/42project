/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kejoseph <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 14:53:37 by kejoseph          #+#    #+#             */
/*   Updated: 2022/02/03 14:34:01 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_ft(int *nbr)
{
	*nbr = 42;
}
/*
int main(void){
	int nbr;
	int *pnbr;

	pnbr = &nbr;
	ft_ft(pnbr);
	printf("the number through pointer is %d", nbr);
}
*/
