/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kejoseph <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 14:59:32 by kejoseph          #+#    #+#             */
/*   Updated: 2022/02/03 14:35:26 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}

int main(void){
	int a, b, div, mod, *ptr1, *ptr2;
	a = 12;
	b = 5;
	ptr1 = &div;
	ptr2 = &mod;

	ft_div_mod(a, b, ptr1, ptr2);

	printf("The division of two numbers is %d\n", div);
	printf("The modulus of two numbers is %d", mod);
}
