/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kaizhang <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 22:06:32 by kaizhang          #+#    #+#             */
/*   Updated: 2022/01/26 00:21:31 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include<unistd.h>

int	ft_atoi(char *str)
{
	int	i;
	int	sign;
	int	nbr;

	i = 0;
	sign = 1;
	nbr = 0;
	while (str[i] == '\t' || str[i] == '\n' || str[i] == '\v'
		|| str[i] == '\f' || str[i] == '\r' || str[i] == ' ')
	{
		i++;
	}
	while (str[i] == '-' || str[i] == '+')
	{
// sign *= -1
		if (str[i] == '-')
			sign = sign * (-1);
				i++;
	}
	while (str[i] < '9' && str[i] > '0')
	{
		nbr = (nbr * 10) + (str[i] - '0');
		i++;
	}
	return (nbr * sign);
}

int	main(void)
{
	char a[] = "   ---+--+1234ab567";

	printf("%d\n", ft_atoi(a));
	printf("%d\n", ft_atoi("------12AB34"));
	printf("%d\n", ft_atoi("------A12AB34"));
	printf("%d\n", ft_atoi("------1A2AB34"));
	return(0);
}

