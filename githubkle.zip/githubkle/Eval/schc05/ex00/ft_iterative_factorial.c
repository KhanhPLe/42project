/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/03 13:27:58 by schandra          #+#    #+#             */
/*   Updated: 2022/02/03 13:46:40 by schandra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_factorial(int nb)
{
	int	n;

	n = nb;
	if (n < 0)
	{
		return (0);
	}
	else if (n == 0 || n == 1)
	{
		return (1);
	}
	while (n > 1)
	{
		nb = nb * (n - 1);
		n--;
	}
	return (nb);
}
/*
#include <stdio.h>

int main()
{
	int nb;
	nb = 4;

	printf("factorial = %d\n", ft_iterative_factorial(nb));
}*/
