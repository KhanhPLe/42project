/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/03 14:15:40 by schandra          #+#    #+#             */
/*   Updated: 2022/02/03 14:23:16 by schandra         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_sqrt(int nb)
{
	int	i;

	i = 1;
	if (nb == 1)
	{
		return (1);
	}
	while (i < (nb / i))
	{
		i++;
		if (i == (nb / i) && (nb % i) == 0)
		{
			return (i);
		}
	}
	return (0);
}
/*
#include <stdio.h>
int main()
{
	printf("%d\n", ft_sqrt(1));
	printf("%d\n", ft_sqrt(-64));
	printf("%d\n", ft_sqrt(2147395600));
}*/
