/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/03 13:54:31 by schandra          #+#    #+#             */
/*   Updated: 2022/02/03 17:05:43 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	n;
	int	i;

	n = 1;
	i = nb;
	if (power == 0 || nb == 1)
	{
		return (1);
	}
	else if (power < 0)
	{
		return (0);
	}
	while (n != power)
	{
		nb = 1 * nb;
		n++;
	}
	return (nb);
}
/*
#include <stdio.h>

int	main()
{
	printf("%d\n", ft_iterative_power(5, -3));
}*/
