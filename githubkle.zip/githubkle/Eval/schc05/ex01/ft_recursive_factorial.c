/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/03 13:47:55 by schandra          #+#    #+#             */
/*   Updated: 2022/02/03 17:04:53 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_recursive_factorial(int nb)
{
	int	n;

	n = nb;
	if (n == 0 || n == 1)
	{
		return (1);
	}
	else if (n > 0)
	{
		nb = n * (ft_recursive_factorial (n - 1));
		return (nb);
	}
	return (0);
}
/*
#include <stdio.h>

int main()
{
	int	nb;
	nb = 4;
	printf("factorial = %d\n", ft_recursive_factorial(nb));
}*/
