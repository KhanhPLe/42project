/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phunguye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/27 11:56:38 by phunguye          #+#    #+#             */
/*   Updated: 2022/01/30 12:37:57 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <stdlib.h>

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	char	*join;
	int		total_c;
	int		i;
	int		j;
	int		join_c;

	total_c = 0;
	j = 0;
	while (j < size)
		total_c += (ft_strlen(strs[j++]) + ft_strlen(sep));
	join = malloc(total_c * sizeof (char));
	j = -1;
	join_c = 0;
	while (++j < size)
	{
		i = 0;
		while (strs[j][i] != 0)
			join[join_c++] = strs[j][i++];
		i = 0;
		while (sep[i] != 0 && j < size - 1)
			join[join_c++] = sep[i++];
	}
	join[join_c] = '\0';
	return (join);
}

int	main(void)
{
	char	*strs[10];
	char	sep[] = "______";
	int	size;

	strs[0] = "abcdefg";
	strs[1] = "hijklmn";
	strs[2] = "opqrstuv";
	strs[3] = "wxyz";
	strs[4] = "this is the end";
	size = 5;
	printf("%s", ft_strjoin(size, strs, sep));
	return (0);
}
