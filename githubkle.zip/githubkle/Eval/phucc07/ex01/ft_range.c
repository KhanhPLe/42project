/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_range.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phunguye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 10:43:55 by phunguye          #+#    #+#             */
/*   Updated: 2022/01/30 12:17:44 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	*ft_range(int min, int max)
{
	int	i;
	int	*str;

	if (min >= max)
		return (0);
	str = malloc((max - min) * (sizeof (int)));
	if (str == NULL)
		return (0);
	i = 0;
	while (min < max)
	{
		str[i] = min;
		min++;
		i++;
	}
	str[i] = 0;
	return (str);
}

int	main(void)
{
	int	*test;
	int	min;
	int	max;
	int	i;

	min = 13;
	max = 200;
	test = ft_range (min, max);
	i = 0;
	while (i < (max - min))
	{	
		printf ("%d, ", test[i]);
		i++;
	}
	return (0);
}

