/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_range.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: phunguye <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/26 11:51:36 by phunguye          #+#    #+#             */
/*   Updated: 2022/01/30 12:23:13 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <stdio.h>

int	ft_ultimate_range(int **range, int min, int max)
{
	int	n;

	if (max <= min)
	{
		range[0] = NULL;
		return (0);
	}
	range[0] = malloc((max - min) * sizeof(int));
	if (range[0] == NULL)
		return (-1);
	n = 0;
	while (min < max)
	{
		range[0][n] = min;
		n++;
		min++;
	}
	return (n);
}

int	main(void)
{
	int	min;
	int	max;
	int	i;
	int	size;
	int	*ary;

	min = 15;
	max = 199;
	size = ft_ultimate_range(&ary, min, max);
	i = 0;
	printf ("%d\n", size);
	while (i < size)
	{
		printf("%d, ", ary[i]);
		i++;
	}
	return (0);
}

