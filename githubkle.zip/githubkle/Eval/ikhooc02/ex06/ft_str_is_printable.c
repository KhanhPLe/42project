/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ikhoo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/26 14:08:57 by ikhoo             #+#    #+#             */
/*   Updated: 2022/01/26 14:09:01 by ikhoo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < 32 || str [i] > 127)
		{
			return (0);
		}
	i++;
	}
	return (1);
}

/*int	main()
{
	printf("%d\n", ft_str_is_printable("	"));
	printf("%d\n", ft_str_is_printable("ABC+123"));
	return(0);
}*/
