/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ikhoo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/26 13:10:05 by ikhoo             #+#    #+#             */
/*   Updated: 2022/01/27 22:49:17 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	i;

	i = 0;
	while ((src[i]) && (i < n))
	{
		dest[i] = src [i];
		i++;
	}
	return (src);
}

/*int	main()
{
	unsigned	int n;

	n = 5;
	char dest[] = "hello 42 world";
	char src[] = "goodbye";

	ft_strncpy(dest, src, n);
	printf("Source is %s\n", src);
	printf("Destination is %s\n", dest);
	return(0);
}*/
