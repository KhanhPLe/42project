/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ikhoo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/26 14:01:21 by ikhoo             #+#    #+#             */
/*   Updated: 2022/01/26 14:01:25 by ikhoo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < 'a' || str[i] > 'z')
		{
			return (0);
		}
	i++;
	}
	return (1);
}

/*int	main()
{
	printf("%d\n", ft_str_is_lowercase("abcdXYZ"));
	printf("%d\n", ft_str_is_lowercase("abc123"));
	printf("%d\n", ft_str_is_lowercase("xyz"));
	return(0);
}*/
