/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ikhoo <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/26 14:04:27 by ikhoo             #+#    #+#             */
/*   Updated: 2022/01/26 14:04:31 by ikhoo            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	while (str[i])
	{
		if (str[i] < 'A' || str[i] > 'Z')
		{
			return (0);
		}
	i++;
	}
	return (1);
}

/*int	main()
{
	printf("%d\n", ft_str_is_uppercase("XyZ"));
	printf("%d\n", ft_str_is_uppercase("123XYZ"));
	printf("%d\n", ft_str_is_uppercase("5678"));
	printf("%d\n", ft_str_is_uppercase("ABC"));
	return (0);
}*/
