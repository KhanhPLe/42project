/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 13:49:25 by schandra          #+#    #+#             */
/*   Updated: 2022/01/27 13:49:04 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 32 && str[i] <= 127))
		{
			return (0);
		}
		i++;
	}
	return (1);
}

#include <stdio.h>
int	main(void)
{
	char	str1[] = "!@#$%^&*()_+";
	char	str2[] = "<>?>{}|}~~''";
	char	str3[] = "1234567";
	char	str4[] = "	";
	char	str5[] = "";

	printf ("%d\n", ft_str_is_printable(str1));
	printf ("%d\n", ft_str_is_printable(str2));
	printf ("%d\n", ft_str_is_printable(str3));
	printf ("%d\n", ft_str_is_printable(str4));
	printf ("%d\n", ft_str_is_printable(str5));
	return (0);
}
