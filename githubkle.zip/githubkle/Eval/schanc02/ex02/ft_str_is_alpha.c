/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 12:22:17 by schandra          #+#    #+#             */
/*   Updated: 2022/01/27 13:39:49 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	int	i;
	int	isalpha;

	i = 0;
	isalpha = 1;
	while (str[i] != '\0')
	{
		if ((str[i] >= 'A' && str[i] <= 'Z')
			|| (str[i] >= 'a' && str[i] <= 'z'))
		{
			isalpha = 1;
		}
		else
		{
			isalpha = 0;
			break ;
		}
		i++;
	}
	return (isalpha);
}

#include <stdio.h>
int	main(void)
{
	char	str1[] = "123456./7";
	char	str2[] = "hola mi chica favorita";
	char	str3[] = "ABcD";
	char	str4[] = "CHOCOLATE";
	char	str5[] = "chococat";
	char	str6[] = "pa1n";

	printf("%d\n", ft_str_is_alpha(str1));
	printf("%d\n", ft_str_is_alpha(str2));
	printf("%d\n", ft_str_is_alpha(str3));
	printf("%d\n", ft_str_is_alpha(str4));
	printf("%d\n", ft_str_is_alpha(str5));
	printf("%d\n", ft_str_is_alpha(str6));
}
