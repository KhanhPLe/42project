/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/24 13:00:27 by schandra          #+#    #+#             */
/*   Updated: 2022/01/27 13:39:28 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	unsigned int	index;

	index = 0;
	while (index < n && src[index] != '\0')
	{
		dest[index] = src[index];
		index++;
	}
	while (index < n)
	{
			dest[index] = '\0';
			index++;
	}
	return (dest);
}

#include <stdio.h>
int	main(void)
{
	char	str1[] = "samadhi at 42 adelaide";
	char	str2[100];
	int	index;
	index = 0;
	while	(index < 100)
	{
		str2[index] = '\0';
		index++;
	}
	puts(ft_strncpy(str2, str1, 40));
}
