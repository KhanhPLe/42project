/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 13:09:25 by schandra          #+#    #+#             */
/*   Updated: 2022/01/27 13:37:11 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	i;
	int	islowercase;

	i = 0;
	islowercase = 1;
	while (str[i] != '\0')
	{
		if (str[i] >= 'a' && str[i] <= 'z')
		{
			islowercase = 1;
			i++;
		}
		else
		{
			islowercase = 0;
			break ;
		}
	}
	return (islowercase);
}

#include <stdio.h>
int	main(void)
{
	char	str1[] = "abcdefg";
	char	str2[] = "AbdCesdji";
	char	str3[] = "ABCDEFGHI";

	printf("%d\n", ft_str_is_lowercase(str1));
	printf("%d\n", ft_str_is_lowercase(str2));
	printf("%d\n", ft_str_is_lowercase(str3));
}
