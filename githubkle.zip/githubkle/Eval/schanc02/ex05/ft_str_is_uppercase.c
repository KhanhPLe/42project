/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 13:35:20 by schandra          #+#    #+#             */
/*   Updated: 2022/01/27 13:39:56 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	int	i;
	int	isuppercase;

	i = 0;
	isuppercase = 1;
	while (str[i] != '\0')
	{
		if (str[i] >= 'A' && str[i] <= 'Z')
		{
			isuppercase = 1;
			i++;
		}
		else
		{
			isuppercase = 0;
			break ;
		}
	}
	return (isuppercase);
}

#include <stdio.h>
int	main(void)
{
	char	str1[] = "SAMADHI";
	char	str2[] = "samadhi";
	char	str3[] = "saMAdHi";
	char	str4[] = "samadh1";

	printf("%d\n", ft_str_is_uppercase(str1));
	printf("%d\n", ft_str_is_uppercase(str2));
	printf("%d\n", ft_str_is_uppercase(str3));
	printf("%d\n", ft_str_is_uppercase(str4));
}
