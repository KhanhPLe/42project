/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: schandra <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 12:52:33 by schandra          #+#    #+#             */
/*   Updated: 2022/01/27 13:36:17 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	i;
	int	isnumeric;

	i = 0;
	isnumeric = 1;
	while (str[i] != '\0')
	{
		if (str[i] >= '0' && str[i] <= '9')
		{
			isnumeric = 1;
			i++;
		}
		else
		{
			isnumeric = 0;
			break ;
		}
	}
	return (isnumeric);
}

#include <stdio.h>
int	main(void)
{
	char	str1[] = "1234567";
	char	str2[] = "abcdef";
	char	str3[] = "123s45";
	char	str4[] = ";-;";

	printf ("%d\n", ft_str_is_numeric(str1));
	printf ("%d\n", ft_str_is_numeric(str2));
	printf ("%d\n", ft_str_is_numeric(str3));
	printf ("%d\n", ft_str_is_numeric(str4));
}
