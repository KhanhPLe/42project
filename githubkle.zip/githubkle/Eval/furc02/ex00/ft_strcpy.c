/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fo-regan <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 13:04:11 by fo-regan          #+#    #+#             */
/*   Updated: 2022/02/03 10:14:29 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <string.h>
#include <stdio.h>
#include <unistd.h>

char	*ft_strcpy(char *dest, char *src)
{
	int	c;

	c = 0;
	while (src[c] != '\0')
	{
		dest[c] = src[c];
		c++;
	}
		dest[c] = '\0';
	return (dest);
}

int main(void)
{
	char dest[42] = "";

	printf("%d\n", strlen(dest));
	ft_strcpy(dest, "String complete");
	printf("%s", dest);
	return (0);
}
