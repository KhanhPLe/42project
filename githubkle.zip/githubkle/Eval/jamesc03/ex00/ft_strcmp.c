/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjezukai <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 13:51:56 by jjezukai          #+#    #+#             */
/*   Updated: 2022/01/26 17:03:48 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int	i;

	i = 0;
	while (s1[i] != '\0' || s2[i] != '\0')
	{
		if (s1[i] > s2[i])
			return (1);
		if (s1[i] < s2[i])
			return (-1);
		i++;
	}
	return (0);
}

#include <stdio.h>
int main (void)
{
	int test;

	test = ft_strcmp("abc", "abc");
	printf("%d", test);
	test = ft_strcmp("ab", "abc");
	printf("%d", test);
	test = ft_strcmp("bb","ab");
	printf("%d", test);
	test = ft_strcmp("ab","bb");
	printf("%d", test);
	return 0;
}
