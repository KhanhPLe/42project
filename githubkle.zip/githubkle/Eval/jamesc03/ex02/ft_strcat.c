/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjezukai <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 14:17:05 by jjezukai          #+#    #+#             */
/*   Updated: 2022/01/26 17:08:12 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	j;

	i = 0;
	while (dest[i] != '\0')
	{
		i++;
	}
	j = 0;
	while (src[j] != '\0')
	{
		dest[i] = src[j];
		i++;
		j++;
	}
		dest[i] = src[j];
	return (dest);
}


#include <stdio.h>
int main(void)
{
	char s[20] = "SSTARTasdalisfSEND";
	char d[20] = "DSTARTokayfanavDEND";
	ft_strcat(d, s);
	printf("%s",d);
}
