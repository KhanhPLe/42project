/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: jjezukai <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/25 14:17:05 by jjezukai          #+#    #+#             */
/*   Updated: 2022/01/26 17:10:33 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int n)
{
	unsigned int	i;
	unsigned int	j;

	i = 0;
	while (dest[i] != '\0')
	{
		i++;
	}
	j = 0;
	while (src[j] != '\0' && j < n - 1)
	{
		dest[i] = src[j];
		i++;
		j++;
	}
		dest[i] = src[j];
	return (dest);
}


#include <string.h>
#include <stdio.h>
int main(void)
{
	char s[20] = "SSTARTSEND";
	char d[30] = "DSTARTDEND";
	char dd[30] = "DSTARTDEND";
	unsigned int i = 5;
	strncat(dd,s,i);
	ft_strncat(d,s,i);
		printf("%s\n",dd);
		printf("%s\n",d);
}

