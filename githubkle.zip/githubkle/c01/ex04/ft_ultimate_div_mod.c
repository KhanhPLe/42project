/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/16 18:34:27 by kle               #+#    #+#             */
/*   Updated: 2022/01/16 19:43:11 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_ultimate_div_mod(int	*a, int	*b)
{
	int	c;
	int	d;

	c = *a / *b;
	*a = c;
	d = *a % *b;
	*b = d;
}
/*#include<stdio.h>
int main()
{
	int numer;
	int denom;

	numer = 12;
	denom  = 5;
	ft_ultimate_div_mod(&numer, &denom);
	printf("%d %d", numer, denom);
	return 0;
}*/
