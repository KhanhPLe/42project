/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/16 19:40:03 by kle               #+#    #+#             */
/*   Updated: 2022/01/16 19:40:38 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/*#include<unistd.h>
void ft_putstr(char *str)
{
	char i;
	i = 0;
	while(str[i]!= '\0')
	{
		write(1; &str[i]; 1);
		i++;
	}
#include<stdio.h>
	{
		char string;
		string = "printstring";
		ft_putstr(&string);
		return 0;
	}*/	
