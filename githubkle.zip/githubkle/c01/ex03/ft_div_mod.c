/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/16 19:36:53 by kle               #+#    #+#             */
/*   Updated: 2022/01/16 19:37:24 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	*div = a / b;
	*mod = a % b;
}
/*#include <stdio.h>
int main()
{
	int a;
	int b;
	int div;
	int mod;
	
	a = 12;
	b  = 5;
	ft_div_mod(a, b, &div, &mod);
	printf("%d %d", div, mod);
	return 0;
}*/
