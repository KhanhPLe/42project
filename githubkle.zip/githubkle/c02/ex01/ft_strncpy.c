/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/20 09:26:05 by kle               #+#    #+#             */
/*   Updated: 2022/01/20 16:56:15 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncpy(char	*dest, char	*src, unsigned int n)

{
	unsigned int	i;

	i = 0 ;
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (i <  n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}
#include<stdio.h>
int	main()
{
	char string1[100];
	char string2[100];
	printf("Enter first string: \n");
	gets(string1);
	ft_strncpy(string2, string1, 5);
	printf("Second string is: %s\n", string2);
	return 0;
}
