/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/20 10:40:35 by kle               #+#    #+#             */
/*   Updated: 2022/01/20 10:54:18 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	int	i;

	i = 0;
	if (str[i] == 0)
		return (1);
	while (str[i] != '\0')
	{
		if (32 < str[i] && str[i] < 127)
			i++;
		else
			return (0);
	}
	return (1);
}
/*#include<stdio.h>
int	main(void)
{
	char	string1[100] = " ";
	ft_str_is_printable(string1);
	printf("%d\n", ft_str_is_printable(string1));
	return 0;
}*/
