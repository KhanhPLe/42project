/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/20 10:22:42 by kle               #+#    #+#             */
/*   Updated: 2022/01/20 10:27:26 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	int	i;

	i = 0 ;
	if (str[i] == '\0')
	{
		return (1);
	}
	while (str[i] != '\0')
	{
		if (str[i] >= '0' && str[i] <= '9' )
			i++;
		else
			return (0);
	}
	return (1);
}
/*##include<stdio.h>
int main()
{
	char string[100] = "hello";
	ft_str_is_numeric (string);
	printf("%d\n", ft_str_is_numeric(string));
	return 0;
}*/	
