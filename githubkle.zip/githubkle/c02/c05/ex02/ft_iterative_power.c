/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/27 11:04:38 by kle               #+#    #+#             */
/*   Updated: 2022/01/29 10:02:18 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_iterative_power(int nb, int power)
{
	int	result;

	result = 1;
	if (nb == 0 && power == 0)
		return (1);
	if (power < 0)
		return (0);
	while (power >= 1)
	{
		result = nb * result;
		power--;
	}
	return (result);
}
/*#include<stdio.h>
int	main()
{
	printf("%d", ft_iterative_power (-3, 9));
	return (0);
}*/
