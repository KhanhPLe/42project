#include <unistd.h>
char	*mod;
char	*ptr;
void	ft_putnbr(int	nb)
{	
	ptr = mod;
	while (nb > 0 )
	{
	*mod = nb % 10 + '0';
	nb = nb / 10;
	mod++;
	}
	mod--;
	while ( mod >= ptr)
	{
		write( 1, mod, 1);
		mod--;
	}
}
/*
int	ft_strlen(char	*str)
{
	int i;

	i = 0;
	while(str[i] != 0)
		i++;
	return (i);
}
char	*ft_rev_print(char	*str)
{	int	i;

	i = ft_strlen(str);
	i--;
	while (i >= 0 )
	{
		write(1, &str[i], 1);
		i--;
	}
	return(str);
}
*/
#include <stdio.h>
int	main()
{
	int	nb;
	nb = 65;
	ft_putnbr(nb);
	return (0);
}
