/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/20 10:27:42 by kle               #+#    #+#             */
/*   Updated: 2022/01/20 10:31:57 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	int	i;

	i = 0;
	while (str[i] == 0)
		return (1);
	while (str[i] != '\0')
	{
		if ('a' <= str[i] && str[i] <= 'z' )
			i++;
		else
			return (0);
	}
	return (1);
}
/*#include<stdio.h>
int	main(void)
{
	char	string1[100] = "Helloworld";
	ft_str_is_lowercase(string1);
	printf("%d\n", ft_str_is_lowercase(string1));
	return(0);
}*/
