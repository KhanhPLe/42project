/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/22 22:58:34 by kle               #+#    #+#             */
/*   Updated: 2022/01/23 12:59:19 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	i;
	int	j;

	i = 0;
	j = 0;
	while (dest[i] != 0)
			i++;
	while (src[j] != 0)
	{
		dest[i + j] = src[j];
		j++;
	}
		dest[i + j] = '\0';
	return (dest);
}
/*# include <stdio.h>
#include <string.h>

int main()
{
    char    dest[20] = "Hello ";
    char    src[5] = "World";

    printf("%s\n", ft_strcat(dest,src));
	//printf("%s\n", strcat (dest,src));/
	return 0;            
}*/
