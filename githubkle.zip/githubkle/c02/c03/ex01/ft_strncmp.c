/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/22 16:59:03 by kle               #+#    #+#             */
/*   Updated: 2022/01/23 13:11:52 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char	*s1, char	*s2, unsigned int n)

{
	unsigned int	i;

	i = 0;
	if (n == 0)
	{
		return (0);
	}
	while (s1[i] != 0 && s2[i] != 0 && s1[i] == s2[i] && i + 1 < n)
	{
		i++;
	}
	return (s1[i] - s2[i]);
}
/*#include <stdio.h>
#include <string.h>

int main()
{
    char    str1[20] = "hank ";
    char    str2[20] = "abb";
    printf("%d\n", ft_strncmp(str1, str2, 1));
	printf("%d\n", strncmp(str1, str2, 1));
    return 0;
}*/
