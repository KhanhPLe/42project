/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kle <marvin@42.fr>                         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/01/20 10:32:24 by kle               #+#    #+#             */
/*   Updated: 2022/01/20 10:34:59 by kle              ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	int	i;

	i = 0;
	if (str[i] == 0)
		return (1);
	while (str[i] != '\0')
	{
		if ('A' <= str[i] && str[i] <= 'Z')
			i++;
		else
			return (0);
	}
	return (1);
}
/*#include<stdio.h>
int	main(void)
{
	char	string1[100] = "HELLO";
	ft_str_is_uppercase(string1);
	printf("%d\n", ft_str_is_uppercase(string1));
	return(0);
}*/
